#include <iostream>
#include <vector>

using namespace std;

struct segmentTree {
	long long evenSum;
	long long evenAmount;
	long long oddSum;
	long long oddAmount;
};

vector <segmentTree> st;
vector <long long> st2;

void pushIncr(int i, int tl, int tr) {
	if (st2[i] != 0 && tl != tr) {

		st2[2 * i + 1] += st2[i];
		st2[2 * i + 2] += st2[i];

		long long stEs_l = st[2 * i + 1].evenSum;
		long long stEa_l = st[2 * i + 1].evenAmount;
		long long stOs_l = st[2 * i + 1].oddSum;
		long long stOa_l = st[2 * i + 1].oddAmount;

		long long stEs_r = st[2 * i + 2].evenSum;
		long long stEa_r = st[2 * i + 2].evenAmount;
		long long stOs_r = st[2 * i + 2].oddSum;
		long long stOa_r = st[2 * i + 2].oddAmount;

		if (st2[i] % 2 != 0) {
			st[2 * i + 1].evenSum = stOs_l + ((long long)(stOa_l * st2[i]));
			st[2 * i + 1].evenAmount = stOa_l;
			st[2 * i + 1].oddSum = stEs_l + ((long long)(stEa_l * st2[i]));
			st[2 * i + 1].oddAmount = stEa_l;

			st[2 * i + 2].evenSum = stOs_r + ((long long)(stOa_r * st2[i]));
			st[2 * i + 2].evenAmount = stOa_r;
			st[2 * i + 2].oddSum = stEs_r + ((long long)(stEa_r * st2[i]));
			st[2 * i + 2].oddAmount = stEa_r;
		}
		else {
			st[2 * i + 1].evenSum = stEs_l + ((long long)(stEa_l * st2[i]));
			st[2 * i + 1].oddSum = stOs_l + ((long long)(stOa_l * st2[i]));

			st[2 * i + 2].evenSum = stEs_r + ((long long)(stEa_r * st2[i]));
			st[2 * i + 2].oddSum = stOs_r + ((long long)(stOa_r * st2[i]));
		}

		st2[i] = 0;
	}
	return;
}

void update(int i, int tl, int tr, int pos, int val) {
	if (tl == tr) {
		if (val % 2 == 0) {
			st[i].evenSum = val;
			st[i].evenAmount = 1;
			st[i].oddSum = 0;
			st[i].oddAmount = 0;
		}
		else if (val % 2 != 0) {
			st[i].evenSum = 0;
			st[i].evenAmount = 0;
			st[i].oddSum = val;
			st[i].oddAmount = 1;
		}
	}

	else {
		pushIncr(i, tl, tr);

		int tm = (tl + tr) / 2;
		if (pos <= tm) update(2 * i + 1, tl, tm, pos, val);
		else if (pos > tm)  update(2 * i + 2, tm + 1, tr, pos, val);

		st[i].evenSum = st[2 * i + 1].evenSum + st[2 * i + 2].evenSum;
		st[i].evenAmount = st[2 * i + 1].evenAmount + st[2 * i + 2].evenAmount;

		st[i].oddSum = st[2 * i + 1].oddSum + st[2 * i + 2].oddSum;
		st[i].oddAmount = st[2 * i + 1].oddAmount + st[2 * i + 2].oddAmount;
	}
	return;
}

long long sum(int i, int tl, int tr, int l, int r, int op) {
	if (l <= tl && tr <= r) {
		if (op == 3) return st[i].evenSum;
		if (op == 4) return st[i].oddSum;
	}

	if (tr < l || r < tl) {
		return 0;
	}

	pushIncr(i, tl, tr);

	int tm = (tl + tr) / 2;
	return sum(2 * i + 1, tl, tm, l, min(r, tm), op)
		+ sum(2 * i + 2, tm + 1, tr, max(l, tm + 1), r, op);
}

void incr(int i, int tl, int tr, int l, int r) {
	if (l <= tl && tr <= r) {

		unsigned long long stEs = st[i].evenSum;
		int stEa = st[i].evenAmount;

		unsigned long long stOs = st[i].oddSum;
		int stOa = st[i].oddAmount;

		st[i].evenSum = stOs + stOa;
		st[i].evenAmount = stOa;

		st[i].oddSum = stEs + stEa;
		st[i].oddAmount = stEa;

		st2[i] += 1;
		return;
	}

	if (tr < l || r < tl) {
		return;
	}

	pushIncr(i, tl, tr);

	int tm = (tl + tr) / 2;
	incr(2 * i + 1, tl, tm, l, r);
	incr(2 * i + 2, tm + 1, tr, l, r);

	st[i].evenSum = st[2 * i + 1].evenSum + st[2 * i + 2].evenSum;
	st[i].evenAmount = st[2 * i + 1].evenAmount + st[2 * i + 2].evenAmount;

	st[i].oddSum = st[2 * i + 1].oddSum + st[2 * i + 2].oddSum;
	st[i].oddAmount = st[2 * i + 1].oddAmount + st[2 * i + 2].oddAmount;
	return;
}

void build(vector<int> &a, int i, int tl, int tr) {
	if (tl == tr) {
		if (a[tl] % 2 == 0) {
			st[i].evenSum = a[tl];
			st[i].evenAmount = 1;
			st[i].oddSum = 0;
			st[i].oddAmount = 0;
		}
		else if (a[tl] % 2 != 0) {
			st[i].evenSum = 0;
			st[i].evenAmount = 0;
			st[i].oddSum = a[tl];
			st[i].oddAmount = 1;
		}
	}
	else {
		int tm = (tl + tr) / 2;
		build(a, i * 2 + 1, tl, tm);
		build(a, i * 2 + 2, tm + 1, tr);

		st[i].evenSum = st[2 * i + 1].evenSum + st[2 * i + 2].evenSum;
		st[i].evenAmount = st[2 * i + 1].evenAmount + st[2 * i + 2].evenAmount;

		st[i].oddSum = st[2 * i + 1].oddSum + st[2 * i + 2].oddSum;
		st[i].oddAmount = st[2 * i + 1].oddAmount + st[2 * i + 2].oddAmount;
	}
	return;
}

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);

	int n, q;
	cin >> n >> q;

	vector <int> arr(n);
	for (int i = 0; i < n; i++) {
		cin >> arr[i];
	}

	st.resize(4 * n);
	st2.assign(4 * n, 0);

	build(arr, 0, 0, n - 1);

	for (int i = 0; i < q; i++) {
		int op, l, r;
		cin >> op >> l >> r;
		l--;
		r--;

		if (op == 1) {
			r++;
			update(0, 0, n - 1, l, r);
		}

		if (op == 2) {
			incr(0, 0, n - 1, l, r);
		}

		if (op == 3) {
			cout << sum(0, 0, n - 1, l, r, op) << "\n";
		}

		if (op == 4) {
			cout << sum(0, 0, n - 1, l, r, op) << "\n";
		}
	}
	return 0;
}