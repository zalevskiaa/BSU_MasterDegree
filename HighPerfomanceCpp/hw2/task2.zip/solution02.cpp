#include <iostream>
#include <vector>
#include <utility>

struct Field {
    int64_t odd_sum;
    int64_t even_sum;
    int64_t odd_count;
    int64_t even_count;
    int add;

    Field() : odd_sum(0), even_sum(0),
    odd_count(0), even_count(0), add(0) {
    }
};

class SegmentTree {
public:
    SegmentTree(const std::vector<int>& values) : n(values.size()), k(1), array() {
        while(k < n) {
            k *= 2;
        }
        array.resize(2 * k);
        for (int i = 0; i < n; ++i) {
            array[k + i] = Field();
            set_single(k + i, values[i]);
        }
        for (int i = k - 1; i >= 1; --i) {
            collect_result_from_children(i);
        }
        for(int i = k + n; i < 2 * k;i++) {
            array[i] = Field();
        }
    }

    void update_field_main(int position, int new_value) {
        int i = 1;
        int L = 1, R = k;
        while (i < k) {
            push(i);
            if (position <= (L + R) / 2) {
                R = (L + R) / 2;
                i = 2 * i;
            } else {
                L = (L + R) / 2 + 1;
                i = 2 * i + 1;
            }
        }
        i = k + position - 1;
        set_single(i, new_value);
        i /= 2;
        while (i >= 1) {
            collect_result_from_children(i);
            i /= 2;
        }
    }

    int64_t sum_odd(int l, int r) {
        std::pair<int64_t, int64_t> result = sum(l, r, 1, 1, k);
        return result.first;
    }

    int64_t sum_even(int l, int r) {
        std::pair<int64_t, int64_t> result = sum(l, r, 1, 1, k);
        return result.second;
    }

    void add_one_main(int l, int r) {
        add_main(l, r, 1, 1, k, 1);
    }

private:
    std::pair<int64_t, int64_t> sum(int l, int r, int i, int L, int R) {
        if(r < L || l > R) {
            return std::make_pair(0, 0);
        }
        if(l <= L && R <= r) {
            return std::make_pair(array[i].odd_sum, array[i].even_sum);
        }
        push(i);
        std::pair<int64_t, int64_t> left_result = sum(l, r, 2 * i, L, (L + R) / 2);
        std::pair<int64_t, int64_t> right_result = sum(l, r, 2 * i + 1, (L + R) / 2 + 1, R);
        return std::make_pair(left_result.first + right_result.first, left_result.second + right_result.second);
    }

    void add_main(int i, int value) {
        if (value == 0) {
            return;
        }
        if (i < k) {
            array[i].add += value;
        }
        if (value % 2 == 1) {
            std::swap(array[i].odd_count, array[i].even_count);
            std::swap(array[i].odd_sum, array[i].even_sum);
        }
        array[i].odd_sum += array[i].odd_count * value;
        array[i].even_sum += array[i].even_count * value;
    }

    void add_main(int l, int r, int i, int L, int R, int value) {
        if (value == 0) {
            return;
        }
        if (r < L || l > R) {
            return;
        }
        if(l <= L && R <= r) {
            add_main(i, value);
            return;
        }
        push(i);
        add_main(l, r, 2 * i, L, (L + R) / 2, value);
        add_main(l, r, 2 * i + 1, (L + R) / 2 + 1, R, value);
        collect_result_from_children(i);
    }

    void push(int i) {
        add_main(2 * i, array[i].add);
        add_main(2 * i + 1, array[i].add);
        array[i].add = 0;
    }

    void collect_result_from_children(int i) {
        array[i].odd_sum = array[2 * i].odd_sum + array[2 * i + 1].odd_sum;
        array[i].even_sum = array[2 * i].even_sum + array[2 * i + 1].even_sum;
        array[i].odd_count = array[2 * i].odd_count + array[2 * i + 1].odd_count;
        array[i].even_count = array[2 * i].even_count + array[2 * i + 1].even_count;
    }

    void set_single(int i, int value) {
        if (value % 2 == 0) {
            array[i].even_sum = value;
            array[i].even_count = 1;
            array[i].odd_sum = 0;
            array[i].odd_count = 0;
        } else {
            array[i].even_sum = 0;
            array[i].even_count = 0;
            array[i].odd_sum = value;
            array[i].odd_count = 1;
        }
        array[i].add = 0;
    }

    int n, k;
    std::vector<Field> array;
};

int main()
{

    int n, q;
    std::cin>>n>>q;
    std::vector<int> values(n);
    for (int i = 0; i < n; ++i) {
        std::cin>>values[i];
    }
    SegmentTree tree(values);
    for (int i = 0; i < q; ++i) {
        int operation, l, r;
        std::cin>>operation>>l>>r;
        if (operation == 1) {
            tree.update_field_main(l, r);
        } else if (operation == 2) {
            tree.add_one_main(l, r);
        } else if (operation == 3) {
            std::cout<<tree.sum_even(l, r)<<"\n";
        } else if (operation == 4) {
            std::cout<<tree.sum_odd(l, r)<<"\n";
        }
    }
    return 0;
}